package javaGUI;


import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.Box;
import javax.swing.ButtonGroup;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.Color;

public class Filemanager_GUI {
	
	private static int i = 0;
	private static int j = 0;
	public static String text = null;
	public static String oldpath = null;
	public static String newpath = null;
	private static int result = 0;
	private static String PWDresult = null;
	private static String Enterresult = null;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		JLabel label = new JLabel("Please enter your password:");
		JPasswordField jpf = new JPasswordField();
		int password = JOptionPane.showConfirmDialog(null,
		new Object[]{label, jpf}, "Password:",
		JOptionPane.OK_CANCEL_OPTION);
		
		PWDresult = "DISH2022";
		Enterresult = jpf.getText();
		
		System.out.println(Enterresult);
		System.out.println(PWDresult);

		
		
	
	if (Enterresult.equals(PWDresult)) {

		
		JFrame frmFileManager = new JFrame();
		frmFileManager.setResizable(false);
		frmFileManager.setTitle("File Manager V1.0");
		frmFileManager.setBounds(100, 100, 727, 540);
		frmFileManager.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTextField sourcetextfield = new JTextField();
		sourcetextfield.setEditable(false);
		sourcetextfield.setBounds(30, 267, 500, 20);
		sourcetextfield.setText("Select Source folder from where you want to search or Move file");
		sourcetextfield.setColumns(10);
		
		JButton SourcebrowseButton = new JButton("Browse");
		SourcebrowseButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		SourcebrowseButton.setBounds(555, 266, 120, 20);
		SourcebrowseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFileChooser sourcelocation = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
				sourcelocation.setDialogTitle("Select your target Directory: ");
				sourcelocation.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				int returnValue = sourcelocation.showSaveDialog(null);
				if (returnValue == JFileChooser.APPROVE_OPTION) {
					if (sourcelocation.getSelectedFile().isDirectory()) {
						//System.out.println("You selected the directory: " + jfc.getSelectedFile());
						sourcetextfield.setText(String.valueOf(sourcelocation.getSelectedFile()));
					}
				}
				
				
			}
		});
		
		JTextField txtSelectDestinationFolder = new JTextField();
		txtSelectDestinationFolder.setEditable(false);
		txtSelectDestinationFolder.setBounds(30, 335, 500, 20);
		txtSelectDestinationFolder.setText("Select Destination Folder To Move File");
		txtSelectDestinationFolder.setColumns(10);
		
		JButton destinationbrowsebtn = new JButton("Browse");
		destinationbrowsebtn.setFont(new Font("Tahoma", Font.BOLD, 11));
		destinationbrowsebtn.setBounds(555, 335, 120, 20);
		
		destinationbrowsebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFileChooser targetlocation = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
				targetlocation.setDialogTitle("Select your target Directory: ");
				targetlocation.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				int returnValue = targetlocation.showSaveDialog(null);
				if (returnValue == JFileChooser.APPROVE_OPTION) {
					if (targetlocation.getSelectedFile().isDirectory()) {
						//System.out.println("You selected the directory: " + jfc.getSelectedFile());
						txtSelectDestinationFolder.setText(String.valueOf(targetlocation.getSelectedFile()));
					}
				}
				
				
			}
		});
		
		JTextField txtSearchString = new JTextField();
		txtSearchString.setBounds(30, 188, 645, 20);
		txtSearchString.setColumns(10);
		
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setBounds(1623, 145, 0, 0);
		
		JLabel lblNewLabel_4 = new JLabel("Source Folder:");
		lblNewLabel_4.setBounds(30, 246, 150, 14);
		lblNewLabel_4.setFont(new Font("Dialog", Font.BOLD, 14));
		
		JLabel lblNewLabel_5 = new JLabel("Destination Folder:");
		lblNewLabel_5.setBounds(30, 315, 187, 14);
		lblNewLabel_5.setFont(new Font("Dialog", Font.BOLD, 14));
		
		JLabel lblNewLabel_6 = new JLabel("<html><font color='red'>For issue Contact : Jayeshkumar.patel@dish.com</font></html>");
		lblNewLabel_6.setBounds(385, 476, 316, 14);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		JButton btnStart = new JButton("Start");
		btnStart.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnStart.setBounds(249, 418, 150, 23);
		
		JPanel Diroption = new JPanel();
		Diroption.setBounds(20, 60, 219, 88);
		Diroption.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		JLabel lblNewLabel_3 = new JLabel("Select directory option");
		Diroption.add(lblNewLabel_3);
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 14));
		
		JRadioButton rdbtnsubDir = new JRadioButton("SubDirectory");
		rdbtnsubDir.setFont(new Font("Dialog", Font.PLAIN, 12));
		Diroption.add(rdbtnsubDir);
		
		JRadioButton rdbtnwoSubDir = new JRadioButton("w/o SubDirectory");
		rdbtnwoSubDir.setFont(new Font("Dialog", Font.PLAIN, 12));
		Diroption.add(rdbtnwoSubDir);
		rdbtnwoSubDir.setSelected(true);
		
		ButtonGroup Dirgroup = new ButtonGroup();
		Dirgroup.add(rdbtnsubDir);
		Dirgroup.add(rdbtnwoSubDir);
		
		JPanel filetype = new JPanel();
		filetype.setBounds(269, 60, 414, 38);
		filetype.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		JLabel lblNewLabel = new JLabel("Select File Type");
		filetype.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		
		JCheckBox chckbxPDF = new JCheckBox("PDF");
		chckbxPDF.setFont(new Font("Dialog", Font.PLAIN, 12));
		filetype.add(chckbxPDF);
		
		JCheckBox chckbxExcel = new JCheckBox("Excel");
		chckbxExcel.setFont(new Font("Dialog", Font.PLAIN, 12));
		filetype.add(chckbxExcel);
		
		JCheckBox chckbxText = new JCheckBox("Text");
		chckbxText.setFont(new Font("Dialog", Font.PLAIN, 12));
		filetype.add(chckbxText);
		
		JCheckBox Imagebox = new JCheckBox("Image");
		Imagebox.setFont(new Font("Dialog", Font.PLAIN, 12));
		filetype.add(Imagebox);
		
		JCheckBox chckbxAll = new JCheckBox("All");
		chckbxAll.setFont(new Font("Dialog", Font.PLAIN, 12));
		filetype.add(chckbxAll);
		chckbxAll.setSelected(true);
		
		JPanel tasktype = new JPanel();
		tasktype.setBounds(269, 109, 414, 39);
		tasktype.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		JLabel lblNewLabel_1 = new JLabel("Select Task to Perform");
		tasktype.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 14));
		
		ButtonGroup filegroup = new ButtonGroup();
		filegroup.add(chckbxPDF);
		filegroup.add(chckbxExcel);
		filegroup.add(chckbxText);
		filegroup.add(Imagebox);
		filegroup.add(chckbxAll);
		
		JRadioButton rdbtnGETNAME = new JRadioButton("GET only Name");
		rdbtnGETNAME.setFont(new Font("Dialog", Font.PLAIN, 12));
		tasktype.add(rdbtnGETNAME);
		rdbtnGETNAME.setSelected(true);
		
		JRadioButton rdbtnMOVE = new JRadioButton("Move to Folder");
		rdbtnMOVE.setFont(new Font("Dialog", Font.PLAIN, 12));
		tasktype.add(rdbtnMOVE);
		
		ButtonGroup Taskgroup = new ButtonGroup();
		Taskgroup.add(rdbtnGETNAME);
		Taskgroup.add(rdbtnMOVE);
		frmFileManager.getContentPane().setLayout(null);
		frmFileManager.getContentPane().add(lblNewLabel_4);
		frmFileManager.getContentPane().add(lblNewLabel_5);
		frmFileManager.getContentPane().add(Diroption);
		frmFileManager.getContentPane().add(filetype);
		frmFileManager.getContentPane().add(tasktype);
		frmFileManager.getContentPane().add(txtSearchString);
		frmFileManager.getContentPane().add(txtSelectDestinationFolder);
		frmFileManager.getContentPane().add(destinationbrowsebtn);
		frmFileManager.getContentPane().add(sourcetextfield);
		frmFileManager.getContentPane().add(SourcebrowseButton);
		frmFileManager.getContentPane().add(horizontalBox_1);
		frmFileManager.getContentPane().add(btnStart);
		frmFileManager.getContentPane().add(lblNewLabel_6);
		
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox.setBounds(20, 236, 663, 60);
		frmFileManager.getContentPane().add(horizontalBox);
		
		Box horizontalBox_2 = Box.createHorizontalBox();
		horizontalBox_2.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_2.setBounds(20, 307, 663, 60);
		frmFileManager.getContentPane().add(horizontalBox_2);
		
		JLabel lblNewLabel_2 = new JLabel("Type string from file name/type which you want to move or search name");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel_2.setBounds(30, 165, 582, 20);
		frmFileManager.getContentPane().add(lblNewLabel_2);
		
		Box horizontalBox_3 = Box.createHorizontalBox();
		horizontalBox_3.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		horizontalBox_3.setBounds(20, 159, 663, 60);
		frmFileManager.getContentPane().add(horizontalBox_3);
		
		JLabel numberoffile = new JLabel("");
		numberoffile.setFont(new Font("Tahoma", Font.BOLD, 20));
		numberoffile.setBounds(20, 378, 379, 38);
		numberoffile.setForeground(new Color(255, 0, 0));
		frmFileManager.getContentPane().add(numberoffile);
		DefaultTableModel model = new DefaultTableModel();
		JFrame frame = new JFrame("File Manager");
		

	    
		
		
		btnStart.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
					j = 0;
					i = 0;
					text = "";
					
					frame.getContentPane().removeAll();
				
					JTable table = new JTable(model);
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					JLabel numberoffile1 = new JLabel("");

					numberoffile1.setForeground(new Color(255, 0, 0));
					model.setRowCount(0);
					model.setColumnCount(0);
			 
				
				if (sourcetextfield.getText().indexOf("Select Source folder from where you want to search or Move file") >= 0) {
					
					JOptionPane.showMessageDialog(null,"Please Select Source Folder");
	            
					
				} else if (rdbtnMOVE.isSelected() && txtSelectDestinationFolder.getText().indexOf("Select Destination Folder To Move File") >= 0) {
					
					JOptionPane.showMessageDialog(null,"Please Select Destination Folder to move files");
					
					
				} else {
					
					
					if (rdbtnMOVE.isSelected() && rdbtnsubDir.isSelected()) {
					
					JFrame frame = new JFrame();
				    int result = JOptionPane.showConfirmDialog(frame, "You have selected Subdirectory and Move to folder option so do you want create subfolder or dumpall files to selected folder?");
				    model.addColumn("Source File Path");
				    model.addColumn("Target File Path");
				    
					} else if (rdbtnMOVE.isSelected()) {	
						model.addColumn("Source File Path");
					    model.addColumn("Target File Path");
					} else {
						
						model.addColumn("Files name");
						
					}
					
			
				
			
				 

				
		        File[] files = new File(sourcetextfield.getText()).listFiles();
			    
			    if (files != null) {
			    	getFiles(files);
			    }
		    
			    j = model.getRowCount();
			    System.out.println(j);
			    
			    
			    
			    
			    final TableRowSorter<TableModel> sorter;
			    sorter = new TableRowSorter<TableModel>(model);
			    table.setRowSorter(sorter);
			    frame.getContentPane().add(new JScrollPane(table));

			    JPanel pnl = new JPanel();
			    pnl.add(numberoffile1);
			    pnl.add(new JLabel("Filter expression:"));
			    final JTextField txtFE = new JTextField(25);
			    pnl.add(txtFE);
			    
			    numberoffile1.setText("");
			    JButton btnSetFE = new JButton("Search");
			    JButton btn = new JButton("Export");
			    
			    ActionListener al;
			    al = new ActionListener() {
			      public void actionPerformed(ActionEvent e) {
			        String expr = txtFE.getText();
			        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + expr));
			        sorter.setSortKeys(null);
			        
			      }
			    };
			    
			    ActionListener exportexcel;
			    exportexcel = new ActionListener() {
			    	public void actionPerformed(ActionEvent e){
				         if(e.getSource() == btn){
				           JFileChooser fchoose = new JFileChooser();
				           int option = fchoose.showSaveDialog(fchoose);
				           if(option == JFileChooser.APPROVE_OPTION){
				             String name = fchoose.getSelectedFile().getName(); 
				             String path = fchoose.getSelectedFile().getParentFile().getPath();
				             String file = path + "\\" + name + ".xls"; 
				             export(table, new File(file));
				           }
				         }
				    }
			    	
			    };
			    
			    
			    
			    btnSetFE.addActionListener(al);
			    btn.addActionListener(exportexcel);
			    pnl.add(btnSetFE);
			    pnl.add(btn);
			    
			    if (rdbtnGETNAME.isSelected()) {
			    
			    numberoffile1.setText(String.valueOf(j  + " files are found"));
			    numberoffile.setText(String.valueOf(j  + " files are found"));
			    
			    } else {
			    	
			    numberoffile1.setText(String.valueOf(j  + " files are Moved to Destination Folder"));
			    numberoffile.setText(String.valueOf(j  + " files are Moved to Destination Folder"));
			    	
			    }
			    frame.getContentPane().add(pnl, BorderLayout.NORTH);
			    
			    frame.setSize(1000, 1000);
			    
			    if (j==0) {
			    	JOptionPane.showMessageDialog(null,"0 Files are Found");
			    	frame.setVisible(false);
			    }else {
			    	
			    	frame.setVisible(true);
			    	
			    }
			  	
				}
			}
			
			  public void export(JTable table, File file){
				    try
				    {
				      TableModel m = table.getModel();
				      FileWriter fw = new FileWriter(file);
				      for(int i = 0; i < m.getColumnCount(); i++){
				        fw.write(m.getColumnName(i) + "\t");
				      }
				      fw.write("\n");
				      for(int i=0; i < m.getRowCount(); i++) {
				        for(int j=0; j < m.getColumnCount(); j++) {
				          fw.write(m.getValueAt(i,j).toString()+"\t");
				        }
				        fw.write("\n");
				      }
				      fw.close();
				    }
				    catch(IOException e){ System.out.println(e); }
				  }
			
			
			      
			
			

			private void getFiles(File[] files) {
				if (files != null) {
			    for (File file : files) {
			    	
			    	


			    	
			    	
			    	
			
	    	
		    	if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxAll.isSelected() && JOptionPane.NO_OPTION == result) {
			    		
			    		if (file.isDirectory()) {

			    			getFiles(file.listFiles());
		
			    		} else {
			    			if(file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
				    		model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
				    		file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
				    	
				    	
			    		}				    		
		    			}
			    		
			    		
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxPDF.isSelected() && JOptionPane.NO_OPTION == result) {
				    		
			    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if (file.getName().toLowerCase().indexOf(".pdf") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    				
				    				model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
				    				file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
			    		
			    			
		    				}
			    		}
			    		
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxExcel.isSelected() && JOptionPane.NO_OPTION == result) {
			    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if ((file.getName().toLowerCase().indexOf(".xlsx") >= 0 || file.getName().toLowerCase().indexOf(".xlsm") >= 0 || file.getName().toLowerCase().indexOf(".xlsb") >= 0 || file.getName().toLowerCase().indexOf(".xltx") >= 0 || file.getName().toLowerCase().indexOf(".xlw") >= 0|| file.getName().toLowerCase().indexOf(".xml") >= 0 || file.getName().toLowerCase().indexOf(".xla") >= 0 || file.getName().toLowerCase().indexOf(".xlr") >= 0 || file.getName().toLowerCase().indexOf(".csv") >= 0) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    				
				    				model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
				    				file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
			    			
				    			}
			    		}
			    			
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxText.isSelected() && JOptionPane.NO_OPTION == result) {
			    		
			    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if (file.getName().toLowerCase().indexOf("txt") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    			
				    				model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
				    				file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
			    			
			    			
				    			}
				    		}
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && Imagebox.isSelected() && JOptionPane.NO_OPTION == result) {
			    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if ((file.getName().toLowerCase().indexOf(".wmf") >= 0 || file.getName().toLowerCase().indexOf(".jpg") >= 0 || file.getName().toLowerCase().indexOf(".emf") >= 0 || file.getName().toLowerCase().indexOf(".bmp") >= 0 || file.getName().toLowerCase().indexOf(".png") >= 0 || file.getName().toLowerCase().indexOf(".gif")  >= 0 ) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    			
				    				model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
				    				file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
				    		}
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxAll.isSelected()) {
			    		
			    			if (file.isFile()) {
			    				if(file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
				    			model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
				    			file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
				   
				    		}
			    			}
			    		
			    	
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxPDF.isSelected()) {
			    		if (file.isFile()) {
			    		if (file.getName().toLowerCase().indexOf("pdf") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
			    			file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
			    		
			    		}	
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxExcel.isSelected()) {
			    		if (file.isFile()) {
			    		if ((file.getName().toLowerCase().indexOf(".xlsx") >= 0 || file.getName().toLowerCase().indexOf(".xlsm") >= 0 || file.getName().toLowerCase().indexOf(".xlsb") >= 0 || file.getName().toLowerCase().indexOf(".xltx") >= 0 || file.getName().toLowerCase().indexOf(".xlw") >= 0|| file.getName().toLowerCase().indexOf(".xml") >= 0 || file.getName().toLowerCase().indexOf(".xla") >= 0 || file.getName().toLowerCase().indexOf(".xlr") >= 0 || file.getName().toLowerCase().indexOf(".csv") >= 0) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath(),txtSelectDestinationFolder.getText() + "\\" + file.getName()});
			    			file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
			    		}	
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxText.isSelected()) {
			    		if (file.isFile()) {
			    		if (file.getPath().indexOf(".txt") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath(), txtSelectDestinationFolder.getText() + "\\" + file.getName()});
			    			file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
			    	
			    		}	
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnMOVE.isSelected() && Imagebox.isSelected()) {
			    		if (file.isFile()) {
			    		if ((file.getName().toLowerCase().indexOf(".wmf") >= 0 || file.getName().toLowerCase().indexOf(".jpg") >= 0 || file.getName().toLowerCase().indexOf(".emf") >= 0 || file.getName().toLowerCase().indexOf(".bmp") >= 0 || file.getName().toLowerCase().indexOf(".png") >= 0 || file.getName().toLowerCase().indexOf(".gif")  >= 0 ) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath(),txtSelectDestinationFolder.getText() + "\\" + file.getName()});
			    			file.renameTo(new File(txtSelectDestinationFolder.getText() + "\\" + file.getName()));
			    			
			    		}
			    	}
			    	} else if (rdbtnsubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxAll.isSelected()) {
			    		if (file.isDirectory()) {
			    			getFiles(file.listFiles());
			    			
			    		} else {
			    			if(file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
				    		model.insertRow(0, new Object[] { file.getPath()});
		
			    			}
		    			}
			    		
			    	} else if (rdbtnsubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxPDF.isSelected()) {
			    		
			    		
			    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    		} else {
				    			if (file.getName().toLowerCase().indexOf(".pdf") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    		
				    				model.insertRow(0, new Object[] { file.getPath()});
			    		
		    				}
			    		}
			    		
			    	} else if (rdbtnsubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxExcel.isSelected()) {
			    				    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    		} else {
				    			if ((file.getName().toLowerCase().indexOf(".xlsx") >= 0 || file.getName().toLowerCase().indexOf(".xlsm") >= 0 || file.getName().toLowerCase().indexOf(".xlsb") >= 0 || file.getName().toLowerCase().indexOf(".xltx") >= 0 || file.getName().toLowerCase().indexOf(".xlw") >= 0|| file.getName().toLowerCase().indexOf(".xml") >= 0 || file.getName().toLowerCase().indexOf(".xla") >= 0 || file.getName().toLowerCase().indexOf(".xlr") >= 0 || file.getName().toLowerCase().indexOf(".csv") >= 0) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    				
				    				model.insertRow(0, new Object[] { file.getPath()});
			    		
				    			}
			    		}
			    			
			    	} else if (rdbtnsubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxText.isSelected()) {
			    		
			    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    		} else {
				    			if (file.getName().toLowerCase().indexOf("txt") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    				
				    				model.insertRow(0, new Object[] { file.getPath()});
				    			}
			    		}
			    	} else if (rdbtnsubDir.isSelected() && rdbtnGETNAME.isSelected() && Imagebox.isSelected()) {
			    			if (file.isDirectory()) {
				    			getFiles(file.listFiles());
				    		} else {
				    			if ((file.getName().toLowerCase().indexOf(".wmf") >= 0 || file.getName().toLowerCase().indexOf(".jpg") >= 0 || file.getName().toLowerCase().indexOf(".emf") >= 0 || file.getName().toLowerCase().indexOf(".bmp") >= 0 || file.getName().toLowerCase().indexOf(".png") >= 0 || file.getName().toLowerCase().indexOf(".gif")  >= 0 ) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    				
				    				model.insertRow(0, new Object[] { file.getPath()});
			    		
				    		}
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxAll.isSelected()) {
			    		
			    			if (file.isFile()) {
			    				if(file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    			
				    			model.insertRow(0, new Object[] { file.getPath()});
			    				}
				    		}
			    		
			    	
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxPDF.isSelected()) {
			    		if (file.isFile()) {
			    		if (file.getName().toLowerCase().indexOf("pdf") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath()});
			    			
			    		}	
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxExcel.isSelected()) {
			    		if (file.isFile()) {
			    		if ((file.getName().toLowerCase().indexOf(".xlsx") >= 0 || file.getName().toLowerCase().indexOf(".xlsm") >= 0 || file.getName().toLowerCase().indexOf(".xlsb") >= 0 || file.getName().toLowerCase().indexOf(".xltx") >= 0 || file.getName().toLowerCase().indexOf(".xlw") >= 0|| file.getName().toLowerCase().indexOf(".xml") >= 0 || file.getName().toLowerCase().indexOf(".xla") >= 0 || file.getName().toLowerCase().indexOf(".xlr") >= 0 || file.getName().toLowerCase().indexOf(".csv") >= 0) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath()});
			    			
			    		}	
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnGETNAME.isSelected() && chckbxText.isSelected()) {
			    		if (file.isFile()) {
			    		if (file.getName().toLowerCase().indexOf(".txt") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath()});
			    			
			    		}	
			    	}
			    	} else if (rdbtnwoSubDir.isSelected() && rdbtnGETNAME.isSelected() && Imagebox.isSelected()) {
			    		if (file.isFile()) {
			    		if ((file.getName().toLowerCase().indexOf(".wmf") >= 0 || file.getName().toLowerCase().indexOf(".jpg") >= 0 || file.getName().toLowerCase().indexOf(".emf") >= 0 || file.getName().toLowerCase().indexOf(".bmp") >= 0 || file.getName().toLowerCase().indexOf(".png") >= 0 || file.getName().toLowerCase().indexOf(".gif")  >= 0 ) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
			    			model.insertRow(0, new Object[] { file.getPath()});
			    			
			    		}
			    	}
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxAll.isSelected() && JOptionPane.YES_OPTION == result) {
			    		
			    		oldpath = file.getPath().replace(sourcetextfield.getText(),"");
				    	newpath = txtSelectDestinationFolder.getText() + oldpath;
				    	File dir = new File(newpath);
			    		
			    		if (file.isDirectory()) {
					    	
			    			
			    			 if (! dir.exists()){
			    				 dir.mkdir();
			    			 }
			    			
			    			getFiles(file.listFiles());
			    			
			    			
			    			
			    		} else {
			    			if(file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
			    			
				    		model.insertRow(0, new Object[] { file.getPath()});
				    		file.renameTo(new File(newpath));
				    		
				    	
				    	
			    		}				    		
		    			}
			    		
			    		
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxPDF.isSelected() && JOptionPane.YES_OPTION == result) {
			    		oldpath = file.getPath().replace(sourcetextfield.getText(),"");
				    	newpath = txtSelectDestinationFolder.getText() + oldpath;
				    	File dir = new File(newpath);
			    			if (file.isDirectory()) {
			    				
			    				 if (! dir.exists()){
				    				 dir.mkdir();
			    			}
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if (file.getName().toLowerCase().indexOf(".pdf") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    				
				    				model.insertRow(0, new Object[] { file.getPath(),newpath});
				    				file.renameTo(new File(newpath));
			    		
			    			
		    				}
			    		}
			    		
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxExcel.isSelected() && JOptionPane.YES_OPTION == result) {
			    		
			    		oldpath = file.getPath().replace(sourcetextfield.getText(),"");
				    	newpath = txtSelectDestinationFolder.getText() + oldpath;
				    	File dir = new File(newpath);
			    			if (file.isDirectory()) {
			    				;
			    				 if (! dir.exists()){
				    				 dir.mkdir();
			    			}
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if ((file.getName().toLowerCase().indexOf(".xlsx") >= 0 || file.getName().toLowerCase().indexOf(".xlsm") >= 0 || file.getName().toLowerCase().indexOf(".xlsb") >= 0 || file.getName().toLowerCase().indexOf(".xltx") >= 0 || file.getName().toLowerCase().indexOf(".xlw") >= 0|| file.getName().toLowerCase().indexOf(".xml") >= 0 || file.getName().toLowerCase().indexOf(".xla") >= 0 || file.getName().toLowerCase().indexOf(".xlr") >= 0 || file.getName().toLowerCase().indexOf(".csv") >= 0) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    				
				    				model.insertRow(0, new Object[] { file.getPath(),newpath});
				    				file.renameTo(new File(newpath));
			    			
				    			}
			    		}
			    			
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && chckbxText.isSelected() && JOptionPane.YES_OPTION == result) {
			    		oldpath = file.getPath().replace(sourcetextfield.getText(),"");
				    	newpath = txtSelectDestinationFolder.getText() + oldpath;
				    	File dir = new File(newpath);
			    			if (file.isDirectory()) {
			    				
			    				 if (! dir.exists()){
				    				 dir.mkdir();
				    			 }
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if (file.getName().toLowerCase().indexOf("txt") >= 0 && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    			
				    				model.insertRow(0, new Object[] { file.getPath(),newpath});
				    				file.renameTo(new File(newpath));
			    			
			    			
				    			}
				    		}
			    	} else if (rdbtnsubDir.isSelected() && rdbtnMOVE.isSelected() && Imagebox.isSelected() && JOptionPane.YES_OPTION == result) {
			    		oldpath = file.getPath().replace(sourcetextfield.getText(),"");
				    	newpath = txtSelectDestinationFolder.getText() + oldpath;
				    	File dir = new File(newpath);
			    			if (file.isDirectory()) {
			    				
			    				 if (! dir.exists()){
				    				 dir.mkdir();
				    			 }
				    			getFiles(file.listFiles());
				    			
				    		} else {
				    			if ((file.getName().toLowerCase().indexOf(".wmf") >= 0 || file.getName().toLowerCase().indexOf(".jpg") >= 0 || file.getName().toLowerCase().indexOf(".emf") >= 0 || file.getName().toLowerCase().indexOf(".bmp") >= 0 || file.getName().toLowerCase().indexOf(".png") >= 0 || file.getName().toLowerCase().indexOf(".gif")  >= 0 ) && file.getName().toLowerCase().indexOf(txtSearchString.getText().toLowerCase()) >= 0) {
				    			
				    				model.insertRow(0, new Object[] { file.getPath(),newpath});
				    				file.renameTo(new File(newpath));
				    		}
			    	}
			    	}
			    	
			    } 
			}
			    			
			}			
			    			
			
		});

		
		frmFileManager.setVisible(true);
		frmFileManager.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
}else if (password != JOptionPane.CANCEL_OPTION) {
	   
		JOptionPane.showMessageDialog(jpf, "Please Enter Correct Password",
	               "Password Error", JOptionPane.ERROR_MESSAGE);
		
		main(null);
	
	}
	}
} 

